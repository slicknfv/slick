see cherryproxy/README.txt for information about this package.

see INSTALL.txt for installation instructions.