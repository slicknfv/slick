from CherryProxy import *
from CherryProxy import __version__, __doc__