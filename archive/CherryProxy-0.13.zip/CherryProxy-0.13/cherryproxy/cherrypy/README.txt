This directory contains the code of the CherryPy WSGI server, provided by the
CherryPy project.

see http://www.cherrypy.org/ for more information.