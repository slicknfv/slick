#ifndef __PRIMETESTER_H
#define __PRIMETESTER_H 1

typedef unsigned long PTYPE;
PTYPE next_prime(PTYPE prime);

#endif
